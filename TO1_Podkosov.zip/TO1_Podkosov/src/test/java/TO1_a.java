import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class TO1_a
{
    boolean prohod = false; //
    public boolean firstTest(ChromeDriver driver) throws InterruptedException
    {
        System.out.println("Выполняем подтест №1");
        System.out.println("Начинаем вход в интернет магазин");
        WebElement enter = driver.findElement(By.xpath("//*[text()=\"Войти\"]/.."));
        enter.click();
        enter = driver.findElement(By.xpath("//*[@id=\"passp-field-login\"]"));
        enter.click();
        System.out.println("Вводм логин и пароль для входа под своим именем");
        enter.sendKeys("anthon.podkosov@yandex.ru");
        enter.sendKeys(Keys.ENTER);
        enter = driver.findElement(By.xpath("//*[@id=\"passp-field-passwd\"]"));
        enter.sendKeys("NOT72290");
        enter.sendKeys(Keys.ENTER);
        System.out.println("логин и пароль введены ищем кнопку <<войти>>");
        WebElement findEnter;
        boolean correctnost = false;
        try {
            findEnter = driver.findElement(By.name("Войти"));
            correctnost = false;
        }
        catch(Exception e){
            correctnost = true;
        }
        if(correctnost)
            System.out.println("Вход выполнен успешно Подтест №1 выполнен успешно");
        else
            System.out.println("Вход не выполнен Подтест №1 не выполнен");
        return correctnost; // вывод результата второго подтеста
    }
}
