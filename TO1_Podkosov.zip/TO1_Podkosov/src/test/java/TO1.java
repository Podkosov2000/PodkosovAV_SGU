import java.util.concurrent.TimeUnit;
import org.openqa.selenium.chrome.ChromeDriver;

public class TO1 {

        ChromeDriver driver;

    @org.junit.Test
    public void main() throws InterruptedException{

        System.setProperty("webdriver.chrome.driver", "/chrome_dv_TEST/chromedriver.exe");
        driver = new ChromeDriver();
        driver.get("https://pokupki.market.yandex.ru/");
        boolean control = false;
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);

        TO1_a test1 = new TO1_a();

        TO1_b test2 = new TO1_b();

        control = test1.firstTest(driver) & test2.secondTest(driver);
        if(control)
            System.out.println("тест выполнен");
        else
            System.out.println("тест не выполнен");
    }
}